#python
import sys
import numpy as np
import math

base = None
motor = None
arm = None
pendulum = None
U = None
yaw_setpoint = 0
yaw_setpoint_key = 0
drive_speed = 0




def sysCall_init():
  
    global K
    
    global pendulum_joint_handle, base_handle, motor_handle , ref, drive_motor

    
    pendulum_joint_handle = sim.getObjectHandle('bike_respondable')
    ref = sim.getObjectHandle("reference_frame")
    motor_handle = sim.getObjectHandle('front_motor') 
    drive_motor =sim.getObjectHandle('drive_motor')
    pass

def sysCall_actuation():
    global drive_speed, yaw_setpoint_key, yaw_setpoint
    
        
    message,data,data2 = sim.getSimulatorMessage()
    
    #print(data)
    if (message == sim.message_keypress):
        if (data[0]==2007): # forward up arrow
                    drive_speed = 0 #add drive wheel speed here
                
        if (data[0]==2008): # backward down arrow
                    drive_speed = -10#add drive wheel speed here
                
        if (data[0]==2009): # left arrow key
                    yaw_setpoint_key += 5#change yaw_setpoint for required turning over here
                        
        if (data[0]==2010): # right arrow key
                    yaw_setpoint_key += -5#change yaw_setpoint for required turning over here
    else:
        drive_speed = drive_speed# This is an example, decide what's best
        yaw_setpoint_key = yaw_setpoint_key# # This is an example, decide what's best
        
    yaw_setpoint = yaw_setpoint_key
    
    
    desired_alpha_dot = 0
    desired_alpha = yaw_setpoint
    desired_theta_dot = 0
    desired_theta = 90
    
    
   
    theta = sim.getJointPosition(motor_handle)
    theta_dot = sim.getJointVelocity(motor_handle)
    
    
    m=sim.getObjectMatrix(pendulum_joint_handle,ref)
    run=math.sqrt((m[0]*m[0])+(m[4]*m[4]))
    rise=m[8]
    
    theta=math.atan2(run,rise)
    thetad=math.degrees(theta)
    
    alpha = math.atan2(m[4], m[0])
    alphad = math.degrees(alpha)
    
    
    
    linear, angular = sim.getObjectVelocity(pendulum_joint_handle)
    alpha_dot = angular[2]
    theta_dot = angular[0]
    
    x1 = desired_alpha_dot - alpha_dot
    x2 = yaw_setpoint - alphad
    x3 = desired_theta_dot - theta_dot
    x4 = -desired_theta + thetad
    #print(x1)
    y=sim.getObjectPosition(pendulum_joint_handle,ref)
    x5= -0.100 + y[1]
    
    
    
    Kp = 10
    Ki = 2
    Kd =2
    error_integral = 0.0  
    previous_error = 0.0  

    
    error = x4 +x2
    error_integral += error
    error_derivative = error - previous_error

    
    u1 = +Kp * error + Ki * error_integral + Kd * error_derivative
    
    Kpa = 0.001
    Kia = 0
    Kda = 0.1
    error_integrala = 0.0  
    previous_errora = 0.0  

    
    errora = x2
    error_integrala += errora
    error_derivativea = errora - previous_errora
    u2 = +Kpa * errora + Kia * error_integrala + Kda * error_derivativea
    
    
    
    u = u1

    
    print(drive_speed)
    sim.setJointTargetVelocity(motor_handle, (1*u))
    sim.setJointTargetVelocity(drive_motor, (drive_speed))
    previous_error = error
    previous_errora = errora
    pass

def sysCall_sensing():
    
    pass

def sysCall_cleanup():
    # do some clean-up here
    pass

# See the user manual or the available code snippets for additional callback functions and details
